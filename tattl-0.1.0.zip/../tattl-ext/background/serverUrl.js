const serverUrl = "https://tattl.herokuapp.com";

export default serverUrl;
